import tempfile


def convert_to_sd(img):
    shapes = []
    return [any(shapes), tempfile.NamedTemporaryFile(delete=False, suffix=".png")]
